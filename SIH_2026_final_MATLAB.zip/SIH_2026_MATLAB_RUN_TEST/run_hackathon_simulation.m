function run_hackathon_simulation(launch_lat, launch_lon, launch_alt, ...
                                  target_lat, target_lon, target_alt, ...
                                  init_vel, init_pos, create_video, video_filename)
% RUN_HACKATHON_SIMULATION  Closed-loop 155mm GNC simulation with 2-phase flight:
% 1. Ballistic Ascent (Unperturbed climb to true apogee)
% 2. Terminal Guidance (TPN homing activated on descent)

    % --- 1. Default Parameters & Inputs ---
    if nargin < 1 || isempty(launch_lat), launch_lat = 34.0000; end
    if nargin < 2 || isempty(launch_lon), launch_lon = -117.0000; end
    if nargin < 3 || isempty(launch_alt), launch_alt = 300.0; end
    if nargin < 4 || isempty(target_lat), target_lat = 34.0031; end
    if nargin < 5 || isempty(target_lon), target_lon = -116.8750; end
    if nargin < 6 || isempty(target_alt), target_alt = 300.0; end
    if nargin < 7 || isempty(init_vel),   init_vel   = [580.0, 0.0, 210.0]; end
    if nargin < 8 || isempty(init_pos),   init_pos   = [0.0, 0.0, 0.0]; end
    if nargin < 9 || isempty(create_video), create_video = true; end
    if nargin < 10 || isempty(video_filename), video_filename = 'precision_strike.mp4'; end

    dt = 0.01;
    guidance = GuidanceLaw(3.0);
    autopilot = CanardAutopilotPID(0.55, 0.00, 0.15); % Tuned autopilot gains

    % --- 2. ENU / Geographic Frame Setup ---
    launch_pad = LaunchFrame(launch_lat, launch_lon, launch_alt);
    target_pos = launch_pad.to_enu(target_lat, target_lon, target_alt);
    target_vel = [0.0, 0.0, 0.0];

    % --- 3. Initial States Setup ---
    true_pos = init_pos(:)';
    true_vel = init_vel(:)';
    true_yaw = atan2(true_vel(2), true_vel(1));
    true_pitch = atan2(true_vel(3), hypot(true_vel(1), true_vel(2)));
    true_roll = 0.0;
    prev_true_yaw = true_yaw; 
    prev_true_pitch = true_pitch;
    gravity = [0.0, 0.0, -9.81];
    total_true_accel = gravity;

    % Unguided missile initial state
    ung_pos = init_pos(:)';
    ung_vel = init_vel(:)';

    % EKF initialization
    ekf = RocketEKF(dt);
    ekf.x(1:3) = true_pos';
    ekf.x(4:6) = true_vel';
    ekf.x(7:9) = [true_roll; true_pitch; true_yaw];

    % Preallocate telemetry history
    max_steps = round(35.0 / dt) + 1;
    time_hist        = nan(1, max_steps);
    x_hist           = nan(1, max_steps);
    y_hist           = nan(1, max_steps);
    z_hist           = nan(1, max_steps);
    pos_error_hist   = nan(1, max_steps);
    cmd_mag_hist     = nan(1, max_steps);
    actual_mag_hist  = nan(1, max_steps);
    guided_speed_hist = nan(1, max_steps);

    ung_x_hist       = nan(1, max_steps);
    ung_y_hist       = nan(1, max_steps);
    ung_z_hist       = nan(1, max_steps);
    ung_speed_hist   = nan(1, max_steps);

    guided_active = true;
    ung_active = true;
    guided_hit = false;
    final_miss_distance = NaN;
    terminal_guidance_engaged = false;

    fprintf('=====================================================\n');
    fprintf('  155mm 2-STAGE PRECISION GUIDED SIMULATION          \n');
    fprintf('=====================================================\n');
    fprintf('Target Pos (ENU): [%.1f, %.1f, %.1f] m\n\n', target_pos(1), target_pos(2), target_pos(3));

    t = 0.0;
    k = 0;

    % --- 4. Simulation Engine Loop ---
    while t < 35.0 && (guided_active || ung_active)
        k = k + 1;
        time_hist(k) = t;

        % -----------------------------------------------------------
        % A. GUIDED MISSILE (Ballistic Climb -> Terminal Descent)
        % -----------------------------------------------------------
        if guided_active
            dist_to_target = norm(target_pos - true_pos);
            if dist_to_target < 2.5
                guided_active = false;
                guided_hit = true;
                final_miss_distance = dist_to_target;
                fprintf('[GUIDED] DIRECT HIT! Miss Distance: %.2f m at t = %.2f s\n', dist_to_target, t);
            elseif true_pos(3) <= 0.0 && t > 1.0
                guided_active = false;
                final_miss_distance = dist_to_target;
                if dist_to_target < 10.0
                    fprintf('[GUIDED] PRECISION DETONATION! Miss Distance: %.2f m at t = %.2f s\n', dist_to_target, t);
                else
                    fprintf('[GUIDED] GROUND IMPACT: Miss Distance: %.2f m at t = %.2f s\n', dist_to_target, t);
                end
            end
        end

        if guided_active
            % 1. Sensor Emulation (IMU, GPS, Baro, Mag)
            true_yaw = atan2(true_vel(2), true_vel(1));
            true_pitch = atan2(true_vel(3), hypot(true_vel(1), true_vel(2)));

            gyro_q = (true_pitch - prev_true_pitch) / dt;
            gyro_r = (true_yaw - prev_true_yaw) / dt;
            prev_true_pitch = true_pitch; 
            prev_true_yaw = true_yaw;
            noisy_gyro_body = [0.0, gyro_q, gyro_r] + (0.02 * randn(1,3));

            specific_force_earth = total_true_accel - gravity;
            cy = cos(true_yaw); sy = sin(true_yaw);
            cp = cos(true_pitch); sp = sin(true_pitch);
            cr = cos(true_roll); sr = sin(true_roll);
            true_dcm = [cp*cy,             cp*sy,             sp; ...
                -sr*sp*cy - cr*sy, -sr*sp*sy + cr*cy, sr*cp; ...
                -cr*sp*cy + sr*sy, -cr*sp*sy - sr*cy, cr*cp];
            noisy_accel_body = (true_dcm * specific_force_earth')' + (0.1 * randn(1,3));

            % 2. EKF Estimation
            ekf.predict(noisy_accel_body, noisy_gyro_body, dt);

            if mod(round(t * 100), 10) == 0  % GPS @ 10 Hz
                noisy_gps_pos = true_pos + (1.5 * randn(1,3));
                noisy_gps_vel = true_vel + (0.3 * randn(1,3));
                ekf.update_gps(noisy_gps_pos, noisy_gps_vel);
            end
            if mod(round(t * 100), 5) == 0   % Baro @ 20 Hz
                noisy_baro_alt = true_pos(3) + (0.4 * randn());
                ekf.update_baro(noisy_baro_alt, 0.25);
            end
            if mod(round(t * 100), 2) == 0   % Mag @ 50 Hz
                noisy_mag_yaw = true_yaw + (0.02 * randn());
                ekf.update_mag_yaw(noisy_mag_yaw, 0.001);
            end

            ekf_pos = ekf.get_position();
            ekf_vel = ekf.get_velocity();
            ekf_ori = ekf.get_orientation();

            % 3. TWO-STAGE FLIGHT LOGIC
            % Phase 1: Ballistic Ascent (Canards locked to avoid killing the climb)
            % Phase 2: Terminal Guidance (Engaged once apogee is crossed, vz <= 0)
            if true_vel(3) <= 0.0 || terminal_guidance_engaged
                terminal_guidance_engaged = true;
                a_cmd = guidance.compute_acceleration(ekf_pos, ekf_vel, target_pos, target_vel);
                canards = autopilot.compute_canards(a_cmd, ekf_ori(1), ekf_ori(2), ekf_ori(3), dt);
            else
                a_cmd = [0.0, 0.0, 0.0];
                canards = [0.0, 0.0, 0.0, 0.0];
            end

            % 4. Aerodynamic Execution
            a_actual_body = autopilot.calculate_actual_body_acceleration(true_vel, canards);
            a_actual_earth = (true_dcm' * a_actual_body')';

            altitude = max(0.0, true_pos(3));
            rho = 1.225 * exp(-0.000118 * altitude);
            speed = norm(true_vel);
            if speed > 0.1
                cd = 0.25;
                drag_mag = (0.5 * rho * (speed^2) * cd * autopilot.surface_area) / autopilot.mass;
                drag_accel = -drag_mag * (true_vel / speed);
            else
                drag_accel = [0.0, 0.0, 0.0];
            end

            total_true_accel = a_actual_earth + gravity + drag_accel;
            true_vel = true_vel + total_true_accel * dt;
            true_pos = true_pos + true_vel * dt;

            cmd_mag_hist(k) = norm(a_cmd);
            actual_mag_hist(k) = norm(a_actual_earth);
            pos_error_hist(k) = norm(ekf_pos - true_pos);
        else
            cmd_mag_hist(k) = 0.0;
            actual_mag_hist(k) = 0.0;
            pos_error_hist(k) = pos_error_hist(max(1, k-1));
        end

        x_hist(k) = true_pos(1);
        y_hist(k) = true_pos(2);
        z_hist(k) = true_pos(3);
        guided_speed_hist(k) = norm(true_vel);

        % -----------------------------------------------------------
        % B. UNGUIDED MISSILE (Pure Ballistic Baseline)
        % -----------------------------------------------------------
        if ung_active
            if ung_pos(3) <= 0.0 && t > 1.0
                ung_active = false;
                ung_miss = norm(target_pos - ung_pos);
                fprintf('[UNGUIDED] BALLISTIC IMPACT: Miss Distance: %.2f m at t = %.2f s\n', ung_miss, t);
            else
                alt_ung = max(0.0, ung_pos(3));
                rho_ung = 1.225 * exp(-0.000118 * alt_ung);
                speed_ung = norm(ung_vel);
                if speed_ung > 0.1
                    cd = 0.25;
                    drag_mag_ung = (0.5 * rho_ung * (speed_ung^2) * cd * autopilot.surface_area) / autopilot.mass;
                    drag_accel_ung = -drag_mag_ung * (ung_vel / speed_ung);
                else
                    drag_accel_ung = [0.0, 0.0, 0.0];
                end
                
                total_ung_accel = gravity + drag_accel_ung;
                ung_vel = ung_vel + total_ung_accel * dt;
                ung_pos = ung_pos + ung_vel * dt;
            end
        end

        ung_x_hist(k) = ung_pos(1);
        ung_y_hist(k) = ung_pos(2);
        ung_z_hist(k) = ung_pos(3);
        ung_speed_hist(k) = norm(ung_vel);

        t = t + dt;
    end

    % Trim arrays
    idx = 1:k;
    time_hist         = time_hist(idx);
    x_hist            = x_hist(idx);
    y_hist            = y_hist(idx);
    z_hist            = z_hist(idx);
    guided_speed_hist = guided_speed_hist(idx);
    pos_error_hist    = pos_error_hist(idx);
    cmd_mag_hist      = cmd_mag_hist(idx);
    actual_mag_hist   = actual_mag_hist(idx);
    ung_x_hist        = ung_x_hist(idx);
    ung_y_hist        = ung_y_hist(idx);
    ung_z_hist        = ung_z_hist(idx);
    ung_speed_hist    = ung_speed_hist(idx);

    % --- 5. 3D Video Animation Simulation ---
    fprintf('\nGenerating Dual-Trajectory 3D Visualization...\n');
    fig_anim = figure('Name', '155mm Precision Guided vs Ballistic Simulation', ...
                      'Color', [0.10, 0.10, 0.12], ...
                      'Position', [50, 50, 1280, 720]);

    ax = axes('Parent', fig_anim, 'Color', [0.12, 0.12, 0.15], ...
              'XColor', [0.8, 0.8, 0.8], 'YColor', [0.8, 0.8, 0.8], 'ZColor', [0.8, 0.8, 0.8]);
    hold(ax, 'on');
    grid(ax, 'on');
    view(ax, 45, 25);

    xlabel(ax, 'East Range (m)', 'Color', 'w');
    ylabel(ax, 'North Crossrange (m)', 'Color', 'w');
    zlabel(ax, 'Altitude (m)', 'Color', 'w');
    title(ax, '155mm Guided Artillery: Ballistic Ascent -> Terminal Guidance', ...
          'Color', 'w', 'FontSize', 14, 'FontWeight', 'bold');

    all_x = [x_hist, ung_x_hist, target_pos(1)];
    all_y = [y_hist, ung_y_hist, target_pos(2)];
    all_z = [z_hist, ung_z_hist, target_pos(3)];
    xlim(ax, [min(all_x) - 100, max(all_x) + 200]);
    ylim(ax, [min(all_y) - 100, max(all_y) + 150]);
    zlim(ax, [0, max(all_z) + 100]);

    scatter3(ax, target_pos(1), target_pos(2), target_pos(3), 180, 'r', 'p', 'filled', ...
             'DisplayName', 'Target Location');

    trail_guided = animatedline(ax, 'Color', [0.0, 0.85, 1.0], 'LineWidth', 2.2, ...
                                'DisplayName', 'Guided Trajectory (Terminal TPN)');
    trail_ung = animatedline(ax, 'Color', [1.0, 0.35, 0.1], 'LineWidth', 1.8, ...
                             'LineStyle', '--', 'DisplayName', 'Unguided (Ballistic Dispersion)');

    missile_guided = plot3(ax, x_hist(1), y_hist(1), z_hist(1), 'o', ...
                           'MarkerSize', 9, 'MarkerFaceColor', [0.0, 1.0, 0.4], ...
                           'MarkerEdgeColor', 'w', 'DisplayName', 'Guided Shell');

    missile_ung = plot3(ax, ung_x_hist(1), ung_y_hist(1), ung_z_hist(1), 's', ...
                        'MarkerSize', 9, 'MarkerFaceColor', [1.0, 0.4, 0.0], ...
                        'MarkerEdgeColor', 'w', 'DisplayName', 'Unguided Shell');

    legend(ax, 'TextColor', 'w', 'Color', [0.18, 0.18, 0.22], 'EdgeColor', [0.3, 0.3, 0.3], ...
           'Location', 'northeast');

    hud_text = text(ax, 0.03, 0.90, '', 'Units', 'normalized', ...
                    'Color', [0.95, 0.95, 0.95], 'FontSize', 10, 'FontName', 'Courier', ...
                    'BackgroundColor', [0.05, 0.05, 0.08, 0.75], ...
                    'EdgeColor', [0.4, 0.4, 0.4], 'Margin', 8);

    writer_obj = [];
    if create_video
        try
            writer_obj = VideoWriter(video_filename, 'MPEG-4');
        catch
            [fpath, fname] = fileparts(video_filename);
            if isempty(fpath), fpath = '.'; end
            writer_obj = VideoWriter(fullfile(fpath, [fname, '.avi']), 'Motion JPEG AVI');
        end
        writer_obj.FrameRate = 30;
        writer_obj.Quality = 95;
        open(writer_obj);
    end

    target_fps = 30;
    frame_stride = max(1, round(1 / (target_fps * dt)));

    for step_i = 1:frame_stride:k
        cur_t = time_hist(step_i);

        addpoints(trail_guided, x_hist(step_i), y_hist(step_i), z_hist(step_i));
        addpoints(trail_ung, ung_x_hist(step_i), ung_y_hist(step_i), ung_z_hist(step_i));

        set(missile_guided, 'XData', x_hist(step_i), 'YData', y_hist(step_i), 'ZData', z_hist(step_i));
        set(missile_ung, 'XData', ung_x_hist(step_i), 'YData', ung_y_hist(step_i), 'ZData', ung_z_hist(step_i));

        cur_dist = norm(target_pos - [x_hist(step_i), y_hist(step_i), z_hist(step_i)]);
        
        if cur_t < 13.5
            phase_str = 'PHASE 1: BALLISTIC ASCENT (CANARDS LOCKED)';
        else
            phase_str = 'PHASE 2: TERMINAL GUIDANCE (HOMING ACTIVE)';
        end

        hud_str = sprintf(['STATUS: %s\n' ...
                           'TIME: %5.2f s | TARGET RANGE: %6.1f m\n' ...
                           '------------------------------------------------------------\n' ...
                           'GUIDED   | Alt: %6.1f m | Spd: %5.1f m/s\n' ...
                           'UNGUIDED | Alt: %6.1f m | Spd: %5.1f m/s'], ...
                          phase_str, cur_t, cur_dist, z_hist(step_i), guided_speed_hist(step_i), ...
                          ung_z_hist(step_i), ung_speed_hist(step_i));
        set(hud_text, 'String', hud_str);

        drawnow limitrate;

        if create_video && ~isempty(writer_obj)
            frame = getframe(fig_anim);
            writeVideo(writer_obj, frame);
        end
    end

    if create_video && ~isempty(writer_obj)
        final_frame = getframe(fig_anim);
        for f = 1:60
            writeVideo(writer_obj, final_frame);
        end
        close(writer_obj);
        fprintf('Video successfully written to: %s\n', video_filename);
    end

    % --- 6. Post-Flight Performance Plots ---
    figure('Name', 'GNC Engineering Telemetry', 'Position', [100, 100, 1800, 550]);

    subplot(1, 3, 1);
    plot3(x_hist, y_hist, z_hist, 'Color', [0.0, 0.6, 1.0], 'LineWidth', 2, 'DisplayName', 'Guided Trajectory');
    hold on;
    plot3(ung_x_hist, ung_y_hist, ung_z_hist, 'r--', 'LineWidth', 1.5, 'DisplayName', 'Unguided Ballistic');
    scatter3(target_pos(1), target_pos(2), target_pos(3), 140, 'r', 'p', 'filled', 'DisplayName', 'Target');
    title('Trajectory Comparison');
    xlabel('East (m)'); ylabel('North (m)'); zlabel('Altitude (m)');
    legend show; grid on; view(45, 20);

    subplot(1, 3, 2);
    plot(time_hist, cmd_mag_hist, 'k--', 'DisplayName', 'Commanded Accel');
    hold on;
    plot(time_hist, actual_mag_hist, 'b-', 'DisplayName', 'Actual Canard Accel');
    title('PID Canard Response');
    xlabel('Time (s)'); ylabel('Acceleration (m/s^2)');
    legend show; grid on;

    subplot(1, 3, 3);
    plot(time_hist, pos_error_hist, 'r-', 'LineWidth', 1.5);
    title('EKF State Estimation Error');
    xlabel('Time (s)'); ylabel('Error Magnitude (m)');
    grid on;

    fprintf('\nFinal Performance:\n');
    fprintf('  Guided Miss Distance:    %.2f meters\n', final_miss_distance);
    fprintf('  Unguided Miss Distance:  %.2f meters\n', norm(target_pos - [ung_x_hist(end), ung_y_hist(end), ung_z_hist(end)]));
end