classdef CanardAutopilotPID < handle
    % CanardAutopilotPID  PID autopilot mapping commanded earth-frame
    % acceleration into 4 canard deflections, plus a simple aero model
    % for the resulting actual body acceleration.
    %
    % Ported from pid_canard.py.
    %
    % NOTE: the original Python had two different shell masses in two
    % different files (48.0 kg here vs 43.2 kg in the "ground truth"
    % physics engine) for what's supposed to be the same shell. This
    % port takes mass/area/Cl_delta as constructor args so you set them
    % ONCE and both the commanded-response model and the ground-truth
    % physics engine can share the same values.

    properties
        kp
        ki
        kd
        integral_error = [0, 0];
        prev_error = [0, 0];
        max_deflection = 15.0;   % degrees

        mass = 43.2;             % kg -- placeholder, tune to real shell mass
        surface_area = 0.0188;   % m^2 -- canard reference area, placeholder
        air_density = 1.225;     % kg/m^3, sea level (see run_hackathon_simulation
                                  % for the altitude-varying density used in the
                                  % ground-truth physics loop)
        Cl_delta = 0.06;         % lift-curve slope per canard, placeholder
    end

    methods
        function obj = CanardAutopilotPID(kp, ki, kd)
            if nargin < 1 || isempty(kp), kp = 1.5; end
            if nargin < 2 || isempty(ki), ki = 0.1; end
            if nargin < 3 || isempty(kd), kd = 0.05; end
            obj.kp = kp; obj.ki = ki; obj.kd = kd;
        end

        function canards = compute_canards(obj, a_cmd_earth, roll, pitch, yaw, dt)
            % roll/pitch/yaw MUST be EKF-estimated values (radians).
            % a_cmd_earth: 1x3. Returns [delta_1 delta_2 delta_3 delta_4] in degrees.

            cy = cos(yaw); sy = sin(yaw);
            cp = cos(pitch); sp = sin(pitch);
            cr = cos(roll); sr = sin(roll);

            dcm = [cp*cy,             cp*sy,             sp; ...
                -sr*sp*cy - cr*sy, -sr*sp*sy + cr*cy, sr*cp; ...
                -cr*sp*cy + sr*sy, -cr*sp*sy - sr*cy, cr*cp];

            a_cmd_body = (dcm * a_cmd_earth(:))';

            % Error: operating without a_current feedback (EKF limitation)
            error = [a_cmd_body(3), a_cmd_body(2)];

            obj.integral_error = obj.integral_error + error * dt;
            max_integral_memory = obj.max_deflection / max(obj.ki, 1e-6);
            obj.integral_error = max(min(obj.integral_error, max_integral_memory), -max_integral_memory);

            derivative = (error - obj.prev_error) / dt;
            pid_output = (obj.kp * error) + (obj.ki * obj.integral_error) + (obj.kd * derivative);
            obj.prev_error = error;

            pitch_cmd = pid_output(1);
            yaw_cmd = pid_output(2);

            delta_1 = yaw_cmd;
            delta_2 = pitch_cmd;
            delta_3 = yaw_cmd;
            delta_4 = pitch_cmd;

            canards = [delta_1, delta_2, delta_3, delta_4];
            canards = max(min(canards, obj.max_deflection), -obj.max_deflection);
        end

        function a_actual = calculate_actual_body_acceleration(obj, current_velocity_earth, canards)
            % current_velocity_earth MUST be ground truth. This is the
            % physical aerodynamics engine (simplified: no Mach-dependent
            % Cl, no spin/Magnus effect -- see README notes).
            yaw_angle_deg = canards(1);
            pitch_angle_deg = canards(2);

            speed = norm(current_velocity_earth);
            dynamic_pressure = 0.5 * obj.air_density * (speed^2);
            aero_multiplier = (dynamic_pressure * obj.surface_area * obj.Cl_delta) / obj.mass;

            a_actual_x = 0.0;
            a_actual_y = aero_multiplier * yaw_angle_deg;
            a_actual_z = aero_multiplier * pitch_angle_deg;

            a_actual = [a_actual_x, a_actual_y, a_actual_z];
        end
    end
end
