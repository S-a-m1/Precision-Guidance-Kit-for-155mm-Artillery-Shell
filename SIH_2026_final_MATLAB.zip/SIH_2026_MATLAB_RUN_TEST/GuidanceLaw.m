classdef GuidanceLaw < handle
    % GuidanceLaw  True Proportional Navigation (TPN) for a 155mm shell.
    % Ported from guidance_law.py.

    properties
        N   % navigation ratio (3.0 is typical/optimal for a static target)
    end

    methods
        function obj = GuidanceLaw(N)
            if nargin < 1 || isempty(N)
                N = 3.0;
            end
            obj.N = N;
        end

        function a_cmd = compute_acceleration(obj, shell_pos, shell_vel, target_pos, target_vel)
            % All inputs 1x3. shell_pos/shell_vel MUST be EKF-estimated
            % values, not ground truth.
            r = target_pos - shell_pos;
            v = target_vel - shell_vel;   % target is static -> just -shell_vel

            distance = norm(r);

            % Safety catch: avoid division by zero at impact
            if distance < 2.5
                a_cmd = [0, 0, 0];
                return
            end

            r_unit = r / distance;
            Vc = -dot(r_unit, v);

            if Vc <= 0
                a_cmd = [0, 0, 0];
                return
            end

            lambda_dot = cross(r, v) / (distance^2);
            a_cmd = obj.N * Vc * cross(lambda_dot, r_unit);
        end
    end
end
