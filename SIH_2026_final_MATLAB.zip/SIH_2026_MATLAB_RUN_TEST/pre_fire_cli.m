function pre_fire_cli()
% PRE_FIRE_CLI  Interactive prompt for pad/target coordinates, then runs
% the full GNC simulation. Ported from pre_fire_cli.py.

    fprintf('=========================================\n');
    fprintf('  155mm PRE-FIRE PROGRAMMING INTERFACE   \n');
    fprintf('=========================================\n');
    fprintf('Awaiting inductive data transfer...\n\n');

    try
        fprintf('--- LAUNCH PAD DATA ---\n');
        lat0 = input('Enter Pad Latitude (deg): ');
        lon0 = input('Enter Pad Longitude (deg): ');
        alt0 = input('Enter Pad Altitude (m): ');

        fprintf('\n--- TARGET DATA ---\n');
        lat_t = input('Enter Target Latitude (deg): ');
        lon_t = input('Enter Target Longitude (deg): ');
        alt_t = input('Enter Target Altitude (m): ');

        if ~isnumeric(lat0) || ~isnumeric(lon0) || ~isnumeric(alt0) ...
                || ~isnumeric(lat_t) || ~isnumeric(lon_t) || ~isnumeric(alt_t)
            error('non-numeric input');
        end

        fprintf('\n[UPLOADING TO FLIGHT COMPUTER...]\n');
        fprintf('Data transferred successfully. Commencing firing sequence.\n\n');

        run_hackathon_simulation(lat0, lon0, alt0, lat_t, lon_t, alt_t);

    catch
        fprintf('\n[ERROR] Invalid input. Please enter numerical values only.\n');
    end
end
