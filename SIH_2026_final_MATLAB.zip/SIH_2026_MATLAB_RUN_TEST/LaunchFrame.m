classdef LaunchFrame < handle
    % LaunchFrame  Converts GPS lat/lon/alt into a local East-North-Up
    % (ENU) meter frame relative to the launch pad. Small-area flat-earth
    % approximation -- fine up to tens of km; swap for a proper ECEF/ENU
    % transform for very long ranges.
    %
    % Ported from geo.py.

    properties (Constant)
        R_EARTH = 6378137.0;  % WGS-84 equatorial radius, meters
    end

    properties
        lat0
        lon0
        alt0
    end

    methods
        function obj = LaunchFrame(lat0_deg, lon0_deg, alt0_m)
            obj.lat0 = deg2rad(lat0_deg);
            obj.lon0 = deg2rad(lon0_deg);
            obj.alt0 = alt0_m;
        end

        function enu = to_enu(obj, lat_deg, lon_deg, alt_m)
            lat = deg2rad(lat_deg);
            lon = deg2rad(lon_deg);
            dlat = lat - obj.lat0;
            dlon = lon - obj.lon0;

            north = dlat * LaunchFrame.R_EARTH;
            east = dlon * LaunchFrame.R_EARTH * cos(obj.lat0);
            up = alt_m - obj.alt0;
            enu = [east, north, up];  % matches EKF's (px,py,pz) = (E,N,Up)
        end
    end
end
